<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Validator;
use App\Http\Controllers\BackendController;
use App\Models\Setting;
use App\Models\Supervisor;
use App\Models\SettingTranslation;
use DB;

class SettingsController extends BackendController {

    private $rules2 = array(
//        'setting.email' => 'required|email',
//        'setting.phone' => 'required',
//        'setting.phone_2' => 'required',
//        'setting.state_of_accommodation' => 'required',
//        'setting.upload_profile_image' => 'required',
//        //'setting.declarative_video_url' => 'required',
//        'setting.declarative_video_type' => 'required',
//        'setting.social_media.facebook' => 'required',
//        'setting.social_media.twitter' => 'required',
//        'setting.social_media.instagram' => 'required',
//        'setting.social_media.google' => 'required',
//        'setting.social_media.linkedin' => 'required',
//        'setting.mena_supervisor.name' => 'required',
////        'setting.mena_supervisor.image' => 'required',
//        'setting.mena_supervisor.contact_numbers' => 'required',
//        'setting.muzdalifah_supervisor.name' => 'required',
////        'setting.muzdalifah_supervisor.image' => 'required',
//        'setting.muzdalifah_supervisor.contact_numbers' => 'required',
//        'setting.arafat_supervisor.name' => 'required',
////        'setting.arafat_supervisor.image' => 'required',
//        'setting.arafat_supervisor.contact_numbers' => 'required',
//        'setting.about_type' => 'required',
    );
    private $rules = array(
        'setting.email' => 'required|email',
        'setting.phone' => 'required',
        'setting.phone_2' => 'required',
        'setting.social_media.facebook' => 'required',
        'setting.social_media.twitter' => 'required',
        'setting.social_media.instagram' => 'required',
        'setting.social_media.google' => 'required',
        'setting.social_media.linkedin' => 'required',
        'supervisors.0.name' => 'required',
        'supervisors.0.contact_numbers' => 'required',
        'supervisors.1.name' => 'required',
        'supervisors.1.contact_numbers' => 'required',
        'supervisors.2.name' => 'required',
        'supervisors.2.contact_numbers' => 'required',
    );

    public function index() {
//          $question_translations_old_update['value'][] = [
//                        'value' => 'test wwww',
//                        'cond' => [['name','=',"'phone'"]],
//                    ];
//          $question_translations_old_update['value'][] = [
//                        'value' => 'aa@aa.com',
//                        'cond' => [['name','=',"'email'"]],
//                    ];
//         $this->updateValues2('\App\Models\Setting', $question_translations_old_update,true);

//$send=$this->sendSMS(["‎966555005344"], 'test');
// dd(json_decode($send->getBody()));
        $this->data['settings'] = Setting::get()->keyBy('name');
        $this->data['settings']['social_media'] = json_decode($this->data['settings']['social_media']->value);
        $this->data['settings']['supervisors'] = json_decode($this->data['settings']['supervisors']->value);
        $this->data['settings_translations'] = SettingTranslation::get()->keyBy('locale');
        return $this->_view('settings/index', 'backend');
    }

    public function index2() {

        $this->data['settings'] = Setting::get()->keyBy('name');
        if ($this->data['settings']) {
            if (isset($this->data['settings']['social_media'])) {
                $this->data['settings']['social_media'] = json_decode($this->data['settings']['social_media']->value);
                $this->data['settings']['mena_supervisor'] = json_decode($this->data['settings']['mena_supervisor']->value);
                $this->data['settings']['muzdalifah_supervisor'] = json_decode($this->data['settings']['muzdalifah_supervisor']->value);
                $this->data['settings']['arafat_supervisor'] = json_decode($this->data['settings']['arafat_supervisor']->value);
            }
        }
        $this->data['settings_translations'] = SettingTranslation::get()->keyBy('locale');
        return $this->_view('settings/index', 'backend');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), $this->rules);
        if ($validator->fails()) {
            $errors = $validator->errors()->toArray();
            return _json('error', $errors);
        }

        DB::beginTransaction();
        try {

            $settings = Setting::get()->keyBy('name');
            $setting = $request->input('setting');

            $data_update = [];
            $supervisors = json_decode($settings['supervisors']->value);
            if (!empty($request->input('supervisors'))) {
                foreach ($request->input('supervisors') as $key => $one) {
                    //dd($one);
                    $supervisors[$key]->name = $one['name'];
                    $supervisors[$key]->contact_numbers = $one['contact_numbers'];
                    if ($image = $request->file('supervisors.' . $key . '.image')) {
                        $supervisors[$key]->image = Supervisor::upload($image, 'supervisors');
                    }
                }
               $data_update['value'][] = [
                    'value' => json_encode($supervisors, JSON_UNESCAPED_UNICODE),
                    'cond' => [['name', '=', "'supervisors'"]],
                ];
           
            }

            foreach ($setting as $key => $value) {
                if ($key == 'social_media') {
                    $value = json_encode($value);
                }
                $data_update['value'][] = [
                    'value' => $value,
                    'cond' => [['name', '=', "'$key'"]],
                ];
            }
        
            $this->updateValues2('\App\Models\Setting', $data_update, true);

            DB::commit();
            return _json('success', _lang('app.updated_successfully'));
        } catch (\Exception $ex) {
            DB::rollback();
            dd($ex);
            return _json('error', _lang('app.error_is_occured'), 400);
        }
    }

    public function store2(Request $request) {

        if ($request->file('setting.about_video_url')) {
            $this->rule['setting.about_video_url'] = 'required|mimes:mp4';
        }
        if ($request->file('setting.declarative_video_url')) {
            $this->rule['setting.declarative_video_url'] = 'required|mimes:mp4';
        }
        $columns_arr = array(
            'about_text' => 'required',
        );
        $this->rules = array_merge($this->rules, $this->lang_rules($columns_arr));
        $validator = Validator::make($request->all(), $this->rules);


        if ($validator->fails()) {
            $errors = $validator->errors()->toArray();
            return _json('error', $errors);
        }
        //dd($request->all());

        DB::beginTransaction();
        try {

            $setting = $request->input('setting');
            $old_settings = Setting::get()->keyBy('name');

            if ($request->file('setting.about_video_url')) {
                $name = Setting::upload_simple($request->file('setting.about_video_url'), 'videos');
                $setting['about_video_url'] = $name;
            } else if (!$request->input('setting.about_video_url')) {
                $setting['about_video_url'] = $old_settings['about_video_url']->value;
                $setting['youtube_url'] = $old_settings['youtube_url']->value;
            }

            if ($request->file('setting.declarative_video_url')) {
                $name = Setting::upload_simple($request->file('setting.declarative_video_url'), 'videos');
                $setting['declarative_video_url'] = $name;
            } else if (!$request->input('setting.declarative_video_url')) {
                $setting['declarative_video_url'] = $old_settings['declarative_video_url']->value;
                $setting['declarative_video_youtube_url'] = $old_settings['declarative_video_youtube_url']->value;
            }

            if ($request->file('setting.muzdalifah_supervisor.image')) {
                $name = Supervisor::upload($request->file('setting.muzdalifah_supervisor.image'), 'supervisors');
                $setting['muzdalifah_supervisor']['image'] = $name;
            }

            if ($request->file('setting.mena_supervisor.image')) {
                $name = Supervisor::upload($request->file('setting.mena_supervisor.image'), 'supervisors');
                $setting['mena_supervisor']['image'] = $name;
            }

            if ($request->file('setting.arafat_supervisor.image')) {
                $name = Supervisor::upload($request->file('setting.arafat_supervisor.image'), 'supervisors');
                $setting['arafat_supervisor']['image'] = $name;
            }
            foreach ($setting as $key => $value) {

                if (in_array($key, ['social_media', 'mena_supervisor', 'muzdalifah_supervisor', 'arafat_supervisor'])) {
                    Setting::updateOrCreate(
                            ['name' => $key], ['value' => json_encode($value)]);
                } else {
                    Setting::updateOrCreate(
                            ['name' => $key], ['value' => $value]);
                }
            }
            $about = $request->input('about_text');
            foreach ($about as $key => $value) {
                SettingTranslation::updateOrCreate(
                        ['locale' => $key], [
                    'locale' => $key, 'about_text' => $about[$key]
                ]);
            }
            DB::commit();
            return _json('success', _lang('app.updated_successfully'));
        } catch (\Exception $ex) {
            DB::rollback();
            dd($ex);
            return _json('error', _lang('app.error_is_occured'), 400);
        }
    }

}
