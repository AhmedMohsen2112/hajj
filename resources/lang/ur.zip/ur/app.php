<?php

return [
    'building_floor_room_1' => 'building floor room',
    'building_floor_room_2' => 'building floor room',
    'locations' => 'cities',
    'building' => 'اندیکاٹنگ',
    'building_2' => 'اماریہ',

    'suite' => 'ونگ',
    'lounge' => 'جمنازیم',
    'tent' => 'صاله /خيمة',
    'room' => 'کمرہ',
    'floor' => 'کا کردار',
    'bed' => 'ایک بیڈ',
    'lounge_no' => 'ہال نمبر',
    'tent_no' => 'شکل نمبر',
];
